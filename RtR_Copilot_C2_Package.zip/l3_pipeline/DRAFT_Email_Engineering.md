# Draft email gửi Engineering · đóng vòng ACT.005 + xác nhận 4 điểm

**Trạng thái:** Lô 2 đã tự quyết theo bằng chứng (Lâm uỷ quyền 27/07) · email này để Engineering XÁC NHẬN chính thức, không phải chờ trả lời mới đi tiếp
**Người gửi:** Lâm · **Người nhận:** Engineering lead · **CC:** đội bảo dưỡng

---

**Subject:** Xác nhận 4 điểm spec baseline chương trình bảo dưỡng HERA

Chào team,

Trong quá trình chuẩn hoá nguồn sự thật cho RtR Copilot, bên mình đối chiếu workbook bảo dưỡng HERA với kernel và đã tạm chốt 4 điểm sau theo bằng chứng hiện có. Nhờ team xác nhận hoặc sửa trong tuần này:

1. **Chuẩn kín nước bụi:** kernel ghi IP54 (certified · verified_primary), baseline workbook ghi IP43 kèm ghi chú "cần Engineering chốt". Tạm chốt: **IP54 là spec hiện hành**. Đúng không, hay IP43 là rating riêng cho điều kiện nào đó?

2. **Tầm điều khiển:** kernel 15 km (chốt CEO 16/07), baseline ghi 10 km "tài liệu khác có 15 km". Tạm chốt: **15 km hiện hành**. Câu hỏi: 10 km có phải config conservative riêng cho chương trình bảo dưỡng hoặc config US không? Nếu có thì cho xin ngữ cảnh để ghi thành fact riêng.

3. **Nhiệt độ:** tạm chốt theo hướng **hai fact cùng đúng**: dải vận hành khuyến cáo bảo dưỡng -20 đến 45 độ C (baseline), năng lực demonstrated -30 độ C (validated Alaska). Team xác nhận cách tách này ổn không?

4. **Toàn bộ mốc bảo dưỡng/warranty trong workbook đang nhãn PROPOSED:** khi nào team duyệt được để gỡ nhãn? Trước khi duyệt, mốc này sẽ hiển thị trong Copilot kèm nhãn "PROPOSED chờ Engineering", nhân viên không được cam kết warranty với khách theo mốc này.

Trả lời nhanh 4 gạch đầu dòng là đủ. Cảm ơn team.

Lâm
